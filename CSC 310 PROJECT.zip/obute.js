function calcNumbers(result){
    form.displayResult.value=form.displayResult.value+result;
    
  }